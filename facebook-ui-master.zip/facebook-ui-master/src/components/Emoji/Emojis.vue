<template>
    <v-card style="border-radius:25px" >
        <v-list-item dense width="100%">
        <!-- <v-layout> -->
            <v-avatar size="20">
                <v-img
                    src="https://emojipedia-us.s3.dualstack.us-west-1.amazonaws.com/thumbs/160/facebook/65/thumbs-up-sign_1f44d.png">
                </v-img>
            </v-avatar>
            <v-avatar size="20" class="ml-2">
                <v-img
                    src="https://emojipedia-us.s3.dualstack.us-west-1.amazonaws.com/thumbs/160/facebook/65/heavy-black-heart_2764.png">
                </v-img>
            </v-avatar>
            <v-avatar size="20" class="ml-2">
                <v-img
                    src="https://emojipedia-us.s3.dualstack.us-west-1.amazonaws.com/thumbs/160/facebook/65/smiling-face-with-open-mouth-and-smiling-eyes_1f604.png">
                </v-img>
            </v-avatar>
            <v-avatar size="20" class="ml-2">
                <v-img
                    src="https://emojipedia-us.s3.dualstack.us-west-1.amazonaws.com/thumbs/160/facebook/65/face-with-open-mouth_1f62e.png">
                </v-img>
            </v-avatar>
            <v-avatar size="20" class="ml-2">
                <v-img
                    src="https://emojipedia-us.s3.dualstack.us-west-1.amazonaws.com/thumbs/160/facebook/65/disappointed-but-relieved-face_1f625.png">
                </v-img>
            </v-avatar>
            <v-avatar size="20" class="ml-2">
                <v-img
                    src="https://emojipedia-us.s3.dualstack.us-west-1.amazonaws.com/thumbs/160/facebook/65/pouting-face_1f621.png">
                </v-img>
            </v-avatar>
            <div class="questrial caption indigo--text ml-2">more</div>
        <!-- </v-layout> -->
        </v-list-item>
    </v-card>
</template>

<script>
export default {

}
</script>

<style>

</style>
